Good day, 

This is Annel Venter. 

Just some notes on the code I did.

1. It would be best to have a page to edit the invoice configs and the values of the configs. But I wasnt sure how complicated you wanted me to go.
2. It would also be best to pull the text that is hard coded in the index.php to pull from a table - this way it would be easier to translate it or change it.
3. In the real world, invoice items will be pulled from a sales order, thus I havent created a grid to add items to the invoice.

Thank you for giving me this opportunity.

